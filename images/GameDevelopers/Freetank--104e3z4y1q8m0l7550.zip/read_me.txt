Hi my name is Robert Brooks I'm the artist of this asset, This asset has been provide to you to use free of charge for your commercial and personal projects.
If you like this asset and you find it useful then you might like my website too! www.gamedeveloperstudio.com. Here you will find many more assets like this one. 



This tank asset comes from a larger set of tank assets all of which can be found on my site, If you feel like supporting me and my  site 
then why not take a look, they are not free like this one but they are really low price and they come in much higher definition they even include the original vector. 
If you don't need more assets just yet you could help out by following my site on twitter facebook or google plus. 


Thanks 

Robert Brooks

You can see full licensing details from the site where you downloaded this asset, or on my website www.gamedeveloperstudio.com